export const teamMembers = [
  {
    name: "Vanshika Pandey",
    role: "GDS Lead",
    quote: "It's quite fun...",
    socials: {
      linkedin: "#",
      twitter: "#",
      instagram: "#"
    }
  },
  {
    name: "John Doe",
    role: "Technical Lead",
    quote: "Building the future of tech...",
    socials: {
      linkedin: "#",
      twitter: "#",
      instagram: "#"
    }
  },
  {
    name: "Jane Smith",
    role: "Design Lead",
    quote: "Design is not just what it looks like...",
    socials: {
      linkedin: "#",
      twitter: "#",
      instagram: "#"
    }
  }
]; 